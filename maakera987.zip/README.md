# Geopolitics Globe

An interactive 3D globe for exploring how countries connect: alliance layers, UN voting, trade, defence and rival ties, active conflicts and strategic chokepoints.

All figures are sample data and are still being verified.

The site is two files: `index.html` (the page) and `countries.json` (country borders, from Natural Earth via world-atlas). It loads the globe.gl library from the jsDelivr CDN.
